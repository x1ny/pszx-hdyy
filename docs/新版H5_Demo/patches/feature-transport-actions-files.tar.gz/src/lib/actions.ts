import type { EventInfo, GeoPoint } from '@/types/itinerary'

/**
 * Platform action helpers: map navigation, tel dialing, .ics calendar export,
 * native share + clipboard fallback, WeChat detection.
 * Targets: iOS Safari 14+, WeChat webview, Chrome Android.
 */

/* ------------------------------------------------------------------ */
/* Environment detection                                               */
/* ------------------------------------------------------------------ */

export function isWeChat(): boolean {
  if (typeof navigator === 'undefined') return false
  return /MicroMessenger/i.test(navigator.userAgent)
}

/* ------------------------------------------------------------------ */
/* Map navigation                                                      */
/* ------------------------------------------------------------------ */

/**
 * Amap universal link. With `callnative=1` the link auto-launches the Amap
 * app when installed and gracefully falls back to the Amap web page (which
 * itself offers Baidu/Tencent jumps) when it is not. WeChat's webview blocks
 * app-launch schemes, so inside WeChat we go straight to the web version
 * (`callnative=0`) to avoid a broken intermediate page.
 */
export function buildNavUrl(geo: GeoPoint): string {
  const name = encodeURIComponent(geo.name)
  const callnative = isWeChat() ? 0 : 1
  return `https://uri.amap.com/marker?position=${geo.lng},${geo.lat}&name=${name}&src=itinerary-h5&callnative=${callnative}`
}

/**
 * Open the map for a location. Primary path: Amap universal link in a new
 * tab. If the popup is blocked (returns null) or window.open throws, fall
 * back to in-place navigation so the user never hits a dead end.
 */
export function openNavigation(geo: GeoPoint): void {
  const url = buildNavUrl(geo)
  try {
    const win = window.open(url, '_blank', 'noopener')
    if (!win) window.location.assign(url)
  } catch {
    window.location.assign(url)
  }
}

/* ------------------------------------------------------------------ */
/* Phone dialing                                                       */
/* ------------------------------------------------------------------ */

/** Normalize a phone number into a tel: href (strips spaces and dashes). */
export function buildTelHref(phone: string): string {
  return `tel:${phone.replace(/[\s-]/g, '')}`
}

/* ------------------------------------------------------------------ */
/* Calendar (.ics) export                                              */
/* ------------------------------------------------------------------ */

/** Escape a value for RFC 5545 TEXT fields. */
function icsEscape(text: string): string {
  return text
    .replace(/\\/g, '\\\\')
    .replace(/;/g, '\\;')
    .replace(/,/g, '\\,')
    .replace(/\r\n|\r|\n/g, '\\n')
}

/** Fold a content line at 75 octets per RFC 5545 §3.1 (CRLF + space). */
function icsFold(line: string): string {
  const encoder = new TextEncoder()
  if (encoder.encode(line).length <= 75) return line
  const parts: string[] = []
  let current = ''
  let octets = 0
  for (const ch of line) {
    const len = encoder.encode(ch).length
    if (octets + len > 75) {
      parts.push(current)
      current = ` ${ch}` // continuation lines begin with a single space
      octets = 1 + len
    } else {
      current += ch
      octets += len
    }
  }
  parts.push(current)
  return parts.join('\r\n')
}

/** Current UTC time as an RFC 5545 DATE-TIME stamp (yyyyMMddTHHmmssZ). */
function icsUtcStamp(d: Date): string {
  const p = (n: number) => String(n).padStart(2, '0')
  return `${d.getUTCFullYear()}${p(d.getUTCMonth() + 1)}${p(d.getUTCDate())}T${p(d.getUTCHours())}${p(
    d.getUTCMinutes(),
  )}${p(d.getUTCSeconds())}Z`
}

/** Build a standards-compliant .ics payload with a VALARM reminder. */
export function buildIcs(event: EventInfo): string {
  const { title, venue, city, intro, ics } = event
  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//itinerary-h5//CN',
    'CALSCALE:GREGORIAN',
    'BEGIN:VEVENT',
    `UID:${ics.start}-${Date.now()}@itinerary-h5`,
    `DTSTAMP:${icsUtcStamp(new Date())}`,
    `DTSTART:${ics.start}`,
    `DTEND:${ics.end}`,
    `SUMMARY:${icsEscape(title)}`,
    `LOCATION:${icsEscape(`${city} · ${venue}`)}`,
    `DESCRIPTION:${icsEscape(intro)}`,
    'BEGIN:VALARM',
    'ACTION:DISPLAY',
    `TRIGGER:-PT${ics.alarm}M`,
    `DESCRIPTION:${icsEscape(title)}`,
    'END:VALARM',
    'END:VEVENT',
    'END:VCALENDAR',
  ]
  return lines.map(icsFold).join('\r\n')
}

export type CalendarResult = 'downloaded' | 'copied'

/** Plain-text schedule used when a real .ics download is not possible. */
function calendarFallbackText(event: EventInfo): string {
  return `${event.title}\n${event.dateText} ${event.timeRange}\n${event.city} · ${event.venue}`
}

/**
 * Export the event as an .ics download (iOS Safari opens it straight into
 * Calendar import). In environments that block Blob downloads — WeChat's
 * webview, or any browser where URL.createObjectURL / the click dispatch
 * fails — falls back to copying a text summary to the clipboard.
 */
export async function addToCalendar(event: EventInfo): Promise<CalendarResult> {
  if (isWeChat()) {
    await copyText(calendarFallbackText(event))
    return 'copied'
  }
  try {
    const ics = buildIcs(event)
    const blob = new Blob([ics], { type: 'text/calendar;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'itinerary.ics'
    document.body.appendChild(a)
    a.click()
    a.remove()
    // Delay revocation so slower browsers still complete the download.
    setTimeout(() => URL.revokeObjectURL(url), 4000)
    return 'downloaded'
  } catch {
    await copyText(calendarFallbackText(event))
    return 'copied'
  }
}

/* ------------------------------------------------------------------ */
/* Clipboard                                                           */
/* ------------------------------------------------------------------ */

/** Copy text; Clipboard API first, execCommand fallback for old webviews. */
export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch {
    // Legacy fallback for non-secure contexts / older webviews.
    try {
      const ta = document.createElement('textarea')
      ta.value = text
      ta.setAttribute('readonly', '')
      ta.style.position = 'fixed'
      ta.style.opacity = '0'
      document.body.appendChild(ta)
      ta.select()
      const ok = document.execCommand('copy')
      ta.remove()
      return ok
    } catch {
      return false
    }
  }
}

/* ------------------------------------------------------------------ */
/* Share                                                               */
/* ------------------------------------------------------------------ */

export type ShareResult = 'shared' | 'copied' | 'wechat-guide' | 'failed'

/**
 * Share via the Web Share API. Fallback chain:
 * WeChat → 'wechat-guide' (caller shows the "tap ··· to forward" mask);
 * no Web Share API / share error → copy the link; copy failed → 'failed'.
 */
export async function shareItinerary(payload: {
  title: string
  text: string
  url: string
}): Promise<ShareResult> {
  if (isWeChat()) return 'wechat-guide'
  if (typeof navigator.share === 'function') {
    try {
      await navigator.share(payload)
      return 'shared'
    } catch (err) {
      // User cancelled the share sheet — treat as a no-op success path.
      if (err instanceof DOMException && err.name === 'AbortError') return 'shared'
    }
  }
  const ok = await copyText(payload.url)
  return ok ? 'copied' : 'failed'
}
